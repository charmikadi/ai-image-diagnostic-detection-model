# ai-imaging-diagnosis
AI-based diagnostic model for analyzing medical imaging data across multiple organs using deep learning 
